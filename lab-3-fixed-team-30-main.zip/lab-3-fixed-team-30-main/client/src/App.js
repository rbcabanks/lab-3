import './App.css';
import React from 'react';
import HomeScreen from './screens/HomeScreen';

const App = () => <HomeScreen />;

export default App;
